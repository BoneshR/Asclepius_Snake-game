#ifndef SNAKE_H_INCLUDED
#define SNAKE_H_INCLUDED

#define UP 1
#define DOWN -1
#define RIGHT 2
#define LEFT -2
#define MAX 60

void initGrid(int, int);
void drawGrid();
void draw_square(int, int);
void draw_Food();
void drawSnake_body();
void random(int&, int&);


#endif

