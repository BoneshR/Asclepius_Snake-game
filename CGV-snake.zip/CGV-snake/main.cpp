#include<gl/glut.h>
#include<stdio.h>
#include<GL/glut.h>
#include<stdlib.h>
#include<windows.h>
#include <iostream>
#include "snake.h"

 
#define columns 40
#define rows 40
#define FPS 10

extern short snake_direction;
 
bool gameover = false;

void reshape_callback(int, int);
void display_callback();
void timer_callback(int);
void keyboard_callback(int, int, int);
int init()
{
	glClearColor(1.0, 1.0, 1.0, 1.0);
	initGrid(columns, rows);
	return 1;
}
int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE);
	glutInitWindowPosition(300, 20);
	glutInitWindowSize(700, 700);
	glutCreateWindow("CGV-project");
	glutDisplayFunc(display_callback);
	glutReshapeFunc(reshape_callback);
	glutTimerFunc(0,timer_callback,0);
	glutSpecialFunc(keyboard_callback);
	init();
	glutMainLoop();
	return 0;

}

void display_callback()
{
	glClear(GL_COLOR_BUFFER_BIT);
	drawGrid();
	drawSnake_body();
	draw_Food();
	glutSwapBuffers();

	if (gameover == true)
	{ 
		MessageBox(NULL, L"Game-Over"  , L"charlie->", MB_ICONSTOP);
		exit(0);

	}
}

void reshape_callback(int w, int h)
{
	glViewport(0.0, 0.0, (GLsizei)w, (GLsizei)h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0.0, columns, 0.0, rows, -1.0, 1.0);
	glMatrixMode(GL_MODELVIEW);

}

void timer_callback(int)
{
	glutPostRedisplay();
	glutTimerFunc(1000 / FPS, timer_callback, 0);

}

void keyboard_callback(int key, int, int)
{
	switch (key)
	{
	case GLUT_KEY_UP:
			if (snake_direction !=DOWN)
				snake_direction = UP;
			break;

		case GLUT_KEY_DOWN:
			if (snake_direction != UP)
				snake_direction = DOWN;
			break;

		case GLUT_KEY_RIGHT:
			if (snake_direction != LEFT)
				snake_direction = RIGHT;
			break;

		case GLUT_KEY_LEFT:
			if (snake_direction != RIGHT)
				snake_direction = LEFT;
			break;

	}
}