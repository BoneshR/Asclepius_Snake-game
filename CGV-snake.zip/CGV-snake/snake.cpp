 #include<gl/glut.h>
#include<stdio.h>
 #include<GL/glut.h>
#include<stdlib.h>
#include <iostream>
#include "snake.h"
#include<windows.h>




int gridX, gridY;
int snake_length = 3;
bool food = true;
int foodX, foodY;

int posX[60] = { 20,20,20,20,20 }, posY[60] = { 20,19,18,17,16 };
short snake_direction = RIGHT;
extern bool gameover;
extern int score;

void initGrid(int x, int y)
{
	gridX = x;
	gridY = y;
}

void drawGrid()
{
	for (int i = 0; i < gridX; i++)
	{
		for (int j = 0; j < gridY; j++)
		{
			draw_square(i, j);
		}
	}
}

void draw_square(int x, int y)
{
	if (x == 0 | y == 0 | x == gridX -1| y == gridY - 1)
	{
		glLineWidth(20.0);
		glColor3f(1.0, 0.0, .0);

	}
	else
	{
		glLineWidth(1.0);
		glColor3f(1.0, 1.0, 0.0);

	}

	glBegin(GL_LINE_LOOP);
	glVertex2f(x, y);
	glVertex2f(x+1, y);
	glVertex2f(x+1, y+1);
	glVertex2f(x, y+1);
	glEnd();

}

void draw_Food()
{
	if (food)
		random(foodX, foodY);
	food = false;

	glColor3f(0.5f, 0.35f, 0.05f);
	glRectd(foodX, foodY, foodX + 1, foodY + 1);
}

void drawSnake_body()
{

	for (int a = snake_length - 1; a > 0; a--)
	{
		posX[a] = posX[a - 1];
		posY[a] = posY[a - 1];
	}


 		if (snake_direction == RIGHT)
		 	posX[0]++;
		else if (snake_direction == DOWN)
			posY[0]--;
		else if (snake_direction == UP)
			posY[0]++;
		else if (snake_direction ==LEFT)
			posX[0]--;

		for (int i = 0; i < snake_length; i++)
		{
			if (i == 0)
				glColor3f(0.0, 0.0, 0.0);
			else
				glColor3f(0.0, 1.0, 0.0);
			glRectd(posX[i], posY[i], posX[i] + 1, posY[i] + 1);
		}

		if (posX[0] == 0 || posX[0] == gridX - 1 || posY[0] == 0 || posY[0] == gridY - 1)
			gameover = true;

		if (posX[0] == foodX && posY[0] == foodY)
		{
			snake_length++;

			if (snake_length > MAX)
				snake_length = MAX;
			food = true;
			}
}

void random(int& x, int& y)
{
	int _maxX = gridX - 2;
	int _maxY = gridY - 2;
	int _min = 1;

	srand(time(NULL));
	x = _min + rand() % (_maxX - _min);
	y= _min + rand() % (_maxY - _min);

}